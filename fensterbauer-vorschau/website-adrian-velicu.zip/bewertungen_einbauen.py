#!/usr/bin/env python3
"""Baut freigegebene Bewertungen in die Website ein.

Ablauf:
  1. Neue Bewertung kommt über das Netlify-Formular "bewertung" (Netlify > Forms).
  2. Wenn sie veröffentlicht werden soll, in bewertungen.json eintragen, z. B.
       [{"name": "Maria", "ort": "Gaukönigshofen", "sterne": 5, "datum": "2026-11", "text": "Sehr sauber gearbeitet …"}]
  3. python3 bewertungen_einbauen.py
Das Skript schreibt die Liste auf ueber-uns.html (zwischen den BEWERTUNGEN-Markern) und ergänzt im
JSON-LD aller Seiten AggregateRating und Review – aber nur, wenn es Bewertungen gibt.
"""
import html, json, os, re

HIER = os.path.dirname(os.path.abspath(__file__))
e = html.escape


def lade():
    daten = json.load(open(os.path.join(HIER, "bewertungen.json"), encoding="utf-8"))
    out = []
    for b in daten:
        s = int(b.get("sterne", 0))
        if not (1 <= s <= 5) or not str(b.get("name", "")).strip() or not str(b.get("text", "")).strip():
            raise SystemExit(f"Ungültige Bewertung: {b!r} (name, text und sterne 1–5 sind Pflicht)")
        out.append({"name": b["name"].strip(), "ort": str(b.get("ort", "")).strip(), "sterne": s,
                    "datum": str(b.get("datum", "")).strip(), "text": b["text"].strip()})
    return out


def liste_html(bew):
    if not bew:
        return ('\n  <p class="bew-leer" data-auf>Noch keine Bewertungen veröffentlicht. Sie waren Kunde bei uns? '
                'Dann freuen wir uns, wenn Sie als Erste oder Erster von Ihrer Erfahrung erzählen.</p>\n')
    teile = []
    for i, b in enumerate(bew):
        wer = e(b["name"]) + (", " + e(b["ort"]) if b["ort"] else "")
        datum = "<span>" + e(b["datum"]) + "</span>" if b["datum"] else ""
        teile.append(
            f'    <blockquote data-auf style="--i:{i % 3}"><span class="sterne" role="img" aria-label="{b["sterne"]} von 5 Sternen">'
            f'{"★" * b["sterne"]}{"☆" * (5 - b["sterne"])}</span><p>„{e(b["text"])}“</p>'
            f'<footer><b>{wer}</b>{datum}</footer></blockquote>')
    return '\n  <div class="stimmen">\n' + "\n".join(teile) + '\n  </div>\n'


def schnitt_html(bew):
    if not bew:
        return ""
    s = round(sum(b["sterne"] for b in bew) / len(bew), 1)
    return (f'<p class="bew-schnitt"><b>{str(s).replace(".", ",")}</b> von 5 Sternen · '
            f'{len(bew)} Bewertung{"en" if len(bew) != 1 else ""}</p>')


def ersetze(text, name, neu):
    muster = re.compile(r"(<!-- " + name + r":START[^>]*-->)(.*?)(<!-- " + name + r":ENDE -->)", re.S)
    return muster.sub(lambda m: m.group(1) + neu + m.group(3), text)


def ld_neu(alt_json, bew):
    d = json.loads(alt_json)
    d.pop("aggregateRating", None)
    d.pop("review", None)
    if bew:
        d["aggregateRating"] = {"@type": "AggregateRating", "ratingValue": round(sum(b["sterne"] for b in bew) / len(bew), 1),
                                "reviewCount": len(bew), "bestRating": 5, "worstRating": 1}
        d["review"] = [{"@type": "Review", "author": {"@type": "Person", "name": b["name"]},
                        "reviewRating": {"@type": "Rating", "ratingValue": b["sterne"], "bestRating": 5},
                        "reviewBody": b["text"], **({"datePublished": b["datum"]} if b["datum"] else {})} for b in bew]
    return json.dumps(d, ensure_ascii=False)


def main():
    bew = lade()
    for name in sorted(os.listdir(HIER)):
        if not name.endswith(".html"):
            continue
        p = os.path.join(HIER, name)
        t = open(p, encoding="utf-8").read()
        alt = t
        t = ersetze(t, "BEWERTUNGEN", liste_html(bew))
        t = ersetze(t, "BEWERTUNG-SCHNITT", schnitt_html(bew))
        m = re.search(r'<!-- FIRMA-LD:START[^>]*--><script type="application/ld\+json">(.*?)</script><!-- FIRMA-LD:ENDE -->', t, re.S)
        if m:
            t = t[:m.start(1)] + ld_neu(m.group(1), bew) + t[m.end(1):]
        if t != alt:
            open(p, "w", encoding="utf-8").write(t)
            print("aktualisiert:", name)
    print(f"{len(bew)} Bewertung(en) eingebaut.")


if __name__ == "__main__":
    main()
