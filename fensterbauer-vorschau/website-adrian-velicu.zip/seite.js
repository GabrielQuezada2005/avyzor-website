/* Adrian Velicu Fenster & Türen (Grundlage Vorlage „Glaserei“): Menü, Cookie, Einblenden, Hero-Scheiben, Wunsch-Planer (mit Merkliste), Glas-Vergleich, Glasbruch-Checkliste, Formulare. Ohne Bibliotheken. */
(function () {
  'use strict';
  var alle = function (s, w) { return Array.prototype.slice.call((w || document).querySelectorAll(s)); };
  var eins = function (s, w) { return (w || document).querySelector(s); };
  var lies = function (k) { try { return window.localStorage.getItem(k); } catch (e) { return null; } };
  var schreib = function (k, v) { try { window.localStorage.setItem(k, v); } catch (e) { /* privat: egal */ } };
  var mm = function (q) { return window.matchMedia ? window.matchMedia(q) : { matches: false }; };
  var ruhig = mm('(prefers-reduced-motion: reduce)').matches;
  var raf = window.requestAnimationFrame ? window.requestAnimationFrame.bind(window) : function (f) { return setTimeout(f, 16); };
  var klemme = function (x, a, b) { return x < a ? a : x > b ? b : x; };
  var de = function (x, n) { return x.toLocaleString('de-DE', { minimumFractionDigits: n || 0, maximumFractionDigits: n || 0 }); };
  var setze = function (sel, txt, w) { var e = eins(sel, w); if (e) e.textContent = txt; };

  /* ---------- Cookie ---------- */
  var cookie = document.getElementById('cookie');
  function cookieZu(wahl) { schreib('cookie-wahl', wahl); if (cookie) cookie.classList.remove('ist-offen'); }
  if (cookie) {
    var gew = lies('cookie-wahl');
    if (!gew) cookie.classList.add('ist-offen');
    alle('[data-cookie]', cookie).forEach(function (k) { k.addEventListener('click', function () { cookieZu(k.getAttribute('data-cookie')); }); });
  }
  alle('[data-cookie-oeffnen]').forEach(function (k) { k.addEventListener('click', function () { if (cookie) cookie.classList.add('ist-offen'); }); });

  /* ---------- Menü ---------- */
  var knopf = eins('[data-menue-knopf]'), menue = eins('[data-menue]');
  if (knopf && menue) {
    var zu = function () { menue.classList.remove('ist-offen'); knopf.setAttribute('aria-expanded', 'false'); knopf.setAttribute('aria-label', 'Menü öffnen'); };
    knopf.addEventListener('click', function () {
      var an = !menue.classList.contains('ist-offen');
      menue.classList.toggle('ist-offen', an); knopf.setAttribute('aria-expanded', an ? 'true' : 'false'); knopf.setAttribute('aria-label', an ? 'Menü schließen' : 'Menü öffnen');
    });
    alle('a', menue).forEach(function (a) { a.addEventListener('click', zu); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') zu(); });
    window.addEventListener('resize', function () { if (window.innerWidth > 1100) zu(); });
  }

  /* ---------- Kopf: Fortschritt, Verstecken beim Runterscrollen ---------- */
  var kopf = eins('[data-kopf]'), balken = eins('[data-fortschritt]');
  var lastY = 0, plan = false;
  function beiScroll() {
    plan = false;
    var y = window.pageYOffset, h = document.documentElement.scrollHeight - window.innerHeight;
    if (balken && h > 0) balken.style.setProperty('--f', (y / h).toFixed(4));
    if (kopf) {
      kopf.classList.toggle('ist-scroll', y > 8);
      var offen = menue && menue.classList.contains('ist-offen');
      kopf.classList.toggle('ist-weg', !offen && !ruhig && y > lastY + 6 && y > 400);
      if (y < lastY - 6 || y < 400) kopf.classList.remove('ist-weg');
    }
    lastY = y;
  }
  window.addEventListener('scroll', function () { if (!plan) { plan = true; raf(beiScroll); } }, { passive: true });
  beiScroll();

  /* ---------- Einblenden ---------- */
  var ziele = alle('[data-auf]');
  if ('IntersectionObserver' in window && !ruhig) {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('ist-da'); io.unobserve(e.target); } });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });
    ziele.forEach(function (z) { io.observe(z); });
  } else {
    ziele.forEach(function (z) { z.classList.add('ist-da'); });
  }
  /* Zahlen zählen hoch */
  alle('[data-zaehl]').forEach(function (z) {
    var ziel = parseInt(z.getAttribute('data-zaehl'), 10);
    if (ruhig || !('IntersectionObserver' in window)) return;
    var o = new IntersectionObserver(function (es) {
      if (!es[0].isIntersecting) return; o.disconnect();
      var t0 = null;
      var schritt = function (t) { if (t0 === null) t0 = t; var p = klemme((t - t0) / 1400, 0, 1); var e = 1 - Math.pow(1 - p, 3); z.textContent = de(Math.round(ziel * e)); if (p < 1) raf(schritt); };
      raf(schritt);
    }, { threshold: 0.6 });
    o.observe(z);
  });

  /* ---------- Hero: Scheiben klären sich, Hauch beim Drüberfahren ---------- */
  var hb = eins('[data-scheiben]');
  if (hb) {
    var klar = function () { hb.classList.add('ist-klar'); };
    if (ruhig) klar(); else raf(function () { setTimeout(klar, 350); });
    var tick = {};
    var hauche = function (e) {
      var s = e.target && e.target.classList && e.target.classList.contains('scheibe') ? e.target : null;
      if (!s || !hb.classList.contains('ist-klar')) return;
      s.classList.add('hauch');
      clearTimeout(tick[s.style.cssText]);
      tick[s.style.cssText] = setTimeout(function () { s.classList.remove('hauch'); }, 900);
    };
    hb.addEventListener('pointermove', hauche);
    hb.addEventListener('pointerdown', hauche);
  }

  /* ---------- Herzstück: Wunsch-Planer (Haus antippen). Alles grobe Wünsche, Maße nimmt Adrian vor Ort. ---------- */
  var haus = eins('[data-haus]');
  if (haus) {
    var bild = eins('[data-haus-bild]', haus), panel = eins('[data-haus-panel]', haus), lst = eins('[data-haus-liste]', haus), hLink = eins('[data-haus-link]', haus);
    var FARBEN = [['Reinweiß', '#f6f7f5'], ['Cremeweiß', '#e9e2cf'], ['Basaltgrau', '#4a5258'], ['Anthrazit', '#2b3238'], ['Dunkelbraun', '#4a352a'], ['Moosgrün', '#2f4a3a']];
    var RAHMEN = ['Kunststoff', 'Holz-Alu', 'Aluminium'];
    var DEF = {
      fenster: { name: 'Fenster', farben: true, dazu: ['Rollladen', 'Insektenschutz', 'Fensterbank'], gr: [
        { k: 'art', l: 'Art', o: ['Einflügelig', 'Zweiflügelig', 'Festverglasung'] },
        { k: 'glas', l: 'Glas', o: ['Zweifachglas', 'Dreifachglas', 'Schallschutzglas', 'Einbruchhemmend'], d: 1 },
        { k: 'rahmen', l: 'Material', o: RAHMEN },
        { k: 'groesse', l: 'Größe (nur grob)', o: ['Klein', 'Mittel', 'Groß', 'Weiß ich nicht'], d: 1, h: { Klein: 'bis ca. 90 × 120 cm', Mittel: 'ca. 120 × 130 cm', 'Groß': 'ab ca. 180 × 140 cm' } },
        { k: 'stk', l: 'Wie viele?', o: ['1', '2–4', '5–8', 'Ganzes Haus'] }] },
      tuer: { name: 'Haustür', farben: true, dazu: ['Mehrfachverriegelung'], gr: [
        { k: 'art', l: 'Art', o: ['Mit Glasausschnitt', 'Vollblatt', 'Mit Seitenteil'] },
        { k: 'rahmen', l: 'Material', o: RAHMEN },
        { k: 'groesse', l: 'Größe (nur grob)', o: ['Standardmaß', 'Breiter', 'Weiß ich nicht'], h: { Standardmaß: 'ca. 100 × 210 cm', Breiter: 'ab ca. 120 cm Breite' } }] },
      tor: { name: 'Garagentor', farben: true, dazu: ['Elektrischer Antrieb'], gr: [
        { k: 'art', l: 'Art', o: ['Sektionaltor', 'Schwingtor', 'Rolltor', 'Seitentor'] },
        { k: 'groesse', l: 'Größe (nur grob)', o: ['Einzelgarage', 'Doppelgarage', 'Weiß ich nicht'], h: { Einzelgarage: 'ca. 240 × 200 cm', Doppelgarage: 'ca. 500 × 200 cm' } },
        { k: 'stk', l: 'Wie viele?', o: ['1', '2', 'Mehr'] }] }
    };
    var ZUST = {}, aktiv = '';
    Object.keys(DEF).forEach(function (el) {
      var z = { an: false, v: {}, dazu: {}, farbe: el === 'fenster' ? 0 : el === 'tuer' ? 3 : 2 };
      DEF[el].gr.forEach(function (g) { z.v[g.k] = g.o[g.d || 0]; });
      DEF[el].dazu.forEach(function (d) { z.dazu[d] = false; });
      ZUST[el] = z;
    });
    var kurz = function (el) {
      var z = ZUST[el], d = DEF[el], t = [];
      d.gr.forEach(function (g) {
        var v = z.v[g.k];
        if (g.k === 'stk') return;
        if (g.k === 'groesse') t.push('Größe grob: ' + v + (g.h && g.h[v] ? ' (' + g.h[v] + ')' : ''));
        else t.push(v);
      });
      t.push(FARBEN[z.farbe][0]);
      d.dazu.forEach(function (x) { if (z.dazu[x]) t.push('mit ' + x); });
      var stk = z.v.stk ? ' ×' + z.v.stk : '';
      return d.name + stk + ': ' + t.join(', ');
    };
    var zeichne = function () {
      var f = ZUST.fenster, t = ZUST.tuer, g = ZUST.tor;
      bild.style.setProperty('--c-fenster', FARBEN[f.farbe][1]);
      bild.style.setProperty('--c-tuer', FARBEN[t.farbe][1]);
      bild.style.setProperty('--c-tor', FARBEN[g.farbe][1]);
      bild.setAttribute('data-glas', f.v.glas); bild.setAttribute('data-f-art', f.v.art);
      bild.setAttribute('data-t-art', t.v.art); bild.setAttribute('data-g-art', g.v.art);
      Object.keys(DEF).forEach(function (el) {
        var gr = bild.querySelector('[data-form-gruppe="' + el + '"]');
        if (gr) { gr.classList.toggle('ist-aktiv', aktiv === el); gr.classList.toggle('ist-liste', ZUST[el].an); }
        var tk = eins('.haus-taste[data-el="' + el + '"]', haus);
        if (tk) { tk.classList.toggle('ist-an', ZUST[el].an); tk.classList.toggle('ist-aktiv', aktiv === el); tk.setAttribute('aria-pressed', ZUST[el].an ? 'true' : 'false'); }
      });
      lst.innerHTML = '';
      var teile = [];
      Object.keys(DEF).forEach(function (el) {
        if (!ZUST[el].an) return;
        var txt = kurz(el); teile.push(txt);
        var li = document.createElement('li');
        var sp = document.createElement('span'); sp.textContent = txt; li.appendChild(sp);
        var x = document.createElement('button'); x.type = 'button'; x.className = 'merk-weg'; x.setAttribute('aria-label', DEF[el].name + ' aus der Liste nehmen'); x.textContent = '×';
        x.addEventListener('click', function () { ZUST[el].an = false; if (aktiv === el) { aktiv = ''; baue(); } zeichne(); });
        li.appendChild(x); lst.appendChild(li);
      });
      if (!teile.length) { var l0 = document.createElement('li'); l0.className = 'leer'; l0.textContent = 'Noch nichts gewählt.'; lst.appendChild(l0); }
      if (hLink) {
        var th = Object.keys(DEF).filter(function (el) { return ZUST[el].an; }).map(function (el) { return { fenster: 'fenster', tuer: 'haustueren', tor: 'garagentore' }[el]; });
        var href = 'kontakt.html?thema=' + encodeURIComponent((th.length ? th : ['fenster']).join('-'));
        if (teile.length) href += '&konfig=' + encodeURIComponent(teile.join(' | ') + ' | Alle Angaben grob geschätzt, Aufmaß vor Ort.');
        hLink.setAttribute('href', href);
      }
    };
    var el_ = function (tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt) e.textContent = txt; return e; };
    var baue = function () {
      panel.innerHTML = '';
      if (!aktiv) {
        panel.appendChild(el_('p', 'zeile', 'Ihre Auswahl'));
        panel.appendChild(el_('p', 'haus-leer', 'Tippen Sie am Haus oder unten auf Fenster, Haustür oder Garagentor. Dann stellen Sie Art, Farbe und ungefähre Größe ein.'));
        return;
      }
      var d = DEF[aktiv], z = ZUST[aktiv], kopf = el_('div', 'haus-panel-kopf');
      kopf.appendChild(el_('p', 'zeile', 'Gewählt: ' + d.name));
      panel.appendChild(kopf);
      d.gr.forEach(function (g) {
        var fs = el_('fieldset', 'haus-gruppe'); fs.appendChild(el_('legend', '', g.l));
        var box = el_('div', 'optionen');
        g.o.forEach(function (o) {
          var lb = el_('label', 'opt'), inp = document.createElement('input');
          inp.type = 'radio'; inp.name = aktiv + '-' + g.k; inp.value = o; inp.checked = z.v[g.k] === o;
          inp.addEventListener('change', function () { z.v[g.k] = o; z.an = true; zeichne(); });
          var sp = el_('span', '', o); if (g.h && g.h[o]) sp.appendChild(el_('small', '', g.h[o]));
          lb.appendChild(inp); lb.appendChild(sp); box.appendChild(lb);
        });
        fs.appendChild(box); panel.appendChild(fs);
      });
      if (d.farben) {
        var ff = el_('fieldset', 'haus-gruppe'); var lg = el_('legend', '', 'Farbe: '); var nm = el_('b', '', FARBEN[z.farbe][0]); lg.appendChild(nm); ff.appendChild(lg);
        var fb = el_('div', 'farben');
        FARBEN.forEach(function (c, i) {
          var lb = el_('label', 'farbe'), inp = document.createElement('input');
          inp.type = 'radio'; inp.name = aktiv + '-farbe'; inp.value = c[0]; inp.checked = z.farbe === i;
          inp.addEventListener('change', function () { z.farbe = i; z.an = true; nm.textContent = c[0]; zeichne(); });
          var sp = el_('span'); sp.style.setProperty('--c', c[1]); sp.title = c[0];
          sp.appendChild(el_('i', 'nur-vorleser', c[0]));
          lb.appendChild(inp); lb.appendChild(sp); fb.appendChild(lb);
        });
        ff.appendChild(fb); panel.appendChild(ff);
      }
      if (d.dazu.length) {
        var fd = el_('fieldset', 'haus-gruppe'); fd.appendChild(el_('legend', '', 'Dazu'));
        var bx = el_('div', 'optionen');
        d.dazu.forEach(function (x) {
          var lb = el_('label', 'opt opt-haken'), inp = document.createElement('input');
          inp.type = 'checkbox'; inp.name = aktiv + '-dazu'; inp.value = x; inp.checked = !!z.dazu[x];
          inp.addEventListener('change', function () { z.dazu[x] = inp.checked; z.an = true; zeichne(); });
          lb.appendChild(inp); lb.appendChild(el_('span', '', x)); bx.appendChild(lb);
        });
        fd.appendChild(bx); panel.appendChild(fd);
      }
    };
    var waehle = function (el) {
      aktiv = el; ZUST[el].an = true; baue(); zeichne();
      if (window.innerWidth <= 900 && panel.scrollIntoView) { try { panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); } catch (e) { panel.scrollIntoView(); } }
    };
    alle('.haus-taste', haus).forEach(function (b) { b.addEventListener('click', function () { waehle(b.getAttribute('data-el')); }); });
    alle('[data-form-gruppe]', bild).forEach(function (gr) {
      gr.addEventListener('click', function () { waehle(gr.getAttribute('data-form-gruppe')); });
    });
    baue(); zeichne();
  }

  /* ---------- Glas-Vergleich ---------- */
  var vg = eins('[data-vergleich]');
  if (vg) {
    var DATEN = [
      { n: 1, t: 'Einfachglas, alt', x: 'Eine einzige Scheibe. Die Wärme wandert fast ungebremst nach draußen, die Scheibe innen wird eiskalt und beschlägt im Winter.', v: 100, ug: '5,8', db: '28 dB' },
      { n: 2, t: 'Zweifach-Isolierglas', x: 'Zwei Scheiben mit Edelgas und Beschichtung. Seit Jahren Standard und für die meisten Häuser ein guter Kompromiss für viele Häuser.', v: 19, ug: '1,1', db: '32 dB' },
      { n: 3, t: 'Dreifach-Wärmeschutzglas', x: 'Drei Scheiben mit Edelgas dazwischen und hauchdünner Metallbeschichtung. Die Wärme bleibt im Raum, die Scheibe innen bleibt warm und beschlägt kaum.', v: 10, ug: '0,6', db: '34 dB' },
      { n: 3, t: 'Schallschutzglas', x: 'Drei Scheiben in unterschiedlicher Dicke und mit schwingungsdämpfender Folie. Straßenlärm, Bahn und Nachbarn werden deutlich leiser.', v: 12, ug: '0,7', db: '44 dB' }
    ];
    var tabs = alle('[data-v]', vg), paket = eins('[data-scheibenpaket]', vg), pfeil = eins('[data-pfeil]', vg), vb = eins('[data-v-balken]', vg);
    var zeige = function (i) {
      var d = DATEN[i];
      tabs.forEach(function (t, k) { t.setAttribute('aria-selected', k === i ? 'true' : 'false'); });
      paket.setAttribute('data-n', d.n);
      pfeil.style.setProperty('--w', Math.max(8, d.v) * 0.9 + '%'); pfeil.style.setProperty('--pa', d.v < 20 ? 0.6 : 1);
      vb.style.setProperty('--b', d.v + '%');
      setze('[data-v-titel]', d.t, vg); setze('[data-v-text]', d.x, vg); setze('[data-v-verlust]', d.v + ' %', vg); setze('[data-v-ug]', d.ug, vg); setze('[data-v-db]', d.db, vg);
      /* Schallschutz: ungleiche Scheiben */
      paket.classList.toggle('ungleich', i === 3);
    };
    tabs.forEach(function (t, k) { t.addEventListener('click', function () { zeige(k); }); });
    tabs.forEach(function (t, k) {
      t.addEventListener('keydown', function (e) {
        if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') { var m = (k + (e.key === 'ArrowRight' ? 1 : tabs.length - 1)) % tabs.length; tabs[m].focus(); zeige(m); }
      });
    });
    zeige(2);
  }

  /* ---------- Glasbruch-Checkliste ---------- */
  var cl = eins('[data-checks]');
  if (cl) {
    var haken = alle('input', cl), cb = eins('[data-check-balken]'), cs = eins('[data-check-stand]');
    var akt = function () {
      var n = haken.filter(function (h) { return h.checked; }).length;
      if (cb) cb.style.setProperty('--s', n / haken.length);
      if (cs) cs.textContent = n === haken.length ? 'Alles erledigt. Jetzt nur noch anrufen.' : n + ' von ' + haken.length + ' erledigt';
    };
    haken.forEach(function (h) { h.addEventListener('change', akt); });
    akt();
  }

  /* ---------- Formular: Auswahl aus dem Wunsch-Planer, Thema aus Link (?thema=garagentore) ---------- */
  var fo = eins('[data-formular]');
  if (fo && window.URLSearchParams) {
    var p = new URLSearchParams(window.location.search);
    var k = p.get('konfig');
    if (k) {
      k = k.slice(0, 1500);
      var hint = eins('[data-konf-hinweis]', fo); if (hint) { hint.hidden = false; eins('b', hint).textContent = k; }
      var fi = fo.elements.konfigurator; if (fi) fi.value = k;
    }
    var th = (p.get('thema') || '').toLowerCase().replace(/[^a-z0-9äöüß-]/g, '');
    if (th) { var ths = th.split('-'); alle('input[name="leistung"]', fo).forEach(function (c) { if (ths.indexOf(c.getAttribute('data-thema')) >= 0) c.checked = true; }); }
  }

  /* ---------- Danke-Seite: Text je nach Formular ---------- */
  var du = eins('[data-danke]');
  if (du && window.URLSearchParams && new URLSearchParams(window.location.search).get('was') === 'bewertung') {
    setze('[data-danke-titel]', 'Danke für Ihre Bewertung.');
    du.textContent = 'Ihre Bewertung ist angekommen. Adrian Velicu liest sie und veröffentlicht sie nach kurzer Prüfung auf der Seite „Über uns“.';
  }
})();
