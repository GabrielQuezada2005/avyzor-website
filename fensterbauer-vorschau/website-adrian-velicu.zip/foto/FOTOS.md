# Fotos austauschen

Jeder Bildplatz hat ein festes Seitenverhältnis und `object-fit: cover`. Ein neues Foto wird also automatisch
passend zugeschnitten. Am einfachsten: das neue Foto **unter demselben Dateinamen** in diesen Ordner legen
(JPG, möglichst unter 300 KB, Motiv mittig). Dann auch den `alt`-Text in der genannten HTML-Datei anpassen.

| Datei | Wo es erscheint | Bildplatz (Seitenverhältnis) | Empfohlene Größe |
|---|---|---|---|
| hero.jpg + hero.webp | Startseite, großes Fensterbild oben rechts (Scheiben-Effekt) | 3 : 2,1 (quer) | 1900 × 1267 px |
| hero-handy.jpg + hero-handy.webp | Startseite oben, nur auf dem Handy | ca. 3 : 4 (hoch) | 1040 × 1387 px |
| aussicht.jpg | Fenster-Planer: Ausblick in der Scheibe | hoch, wird beschnitten | 732 × 1067 px |
| leistung-fenster.jpg | Startseite Karte „Fenster“, Leistungen Abschnitt 01 | 4 : 3 | 1000 × 750 px |
| leistung-tuer.jpg | Startseite Karte „Haustüren“, Leistungen Abschnitt 02 | 4 : 3 | 1000 × 750 px |
| garagentore.jpg | Startseite Karte „Garagentore“, Leistungen Abschnitt 03 | 4 : 3 | 1600 × 1200 px |
| leistung-rollladen.jpg | Startseite Karte „Rollläden & Insektenschutz“, Leistungen Abschnitt 04 | 4 : 3 | 1000 × 750 px |
| leistung-glasbruch.jpg | Startseite Karte „Glasbruch & Reparatur“, Leistungen Abschnitt 05, Glasbruch-Seite oben | 4 : 3 | 1000 × 750 px |
| abbruch.jpg | Startseite Karte „Abbruch & Rückbau“, Leistungen Abschnitt 06, Über uns „Sauber zurückgebaut“ | 4 : 3 bzw. 4 : 5 | 1600 × 1200 px |
| ref-haus.jpg | Startseite „Was möglich ist“, großes Bild links | hoch, ca. 1 : 1,1 | 1400 × 934 px oder größer |
| garagentore-2.jpg | Startseite „Was möglich ist“, oben rechts | quer, ca. 4 : 2,4 | 1600 × 900 px |
| leistung-insektenschutz.jpg | Startseite „Was möglich ist“, unten rechts | quer, ca. 4 : 2,4 | 1000 × 930 px |
| team-montage.jpg | Über uns, Bild neben „Adrian Velicu“ | hoch, bis 560 px hoch | 1000 × 1500 px |
| team-bohrer.jpg | Über uns „Genau montiert“ | 4 : 5 | 1000 × 1250 px |
| team-silikon.jpg | Über uns „Dicht angeschlossen“ | 4 : 5 | 1000 × 1250 px |
| team-glas.jpg | Über uns „Glas mit Gefühl“ | 4 : 5 | 1000 × 1250 px |

Hinweis: Nach dem Tausch von hero.jpg bitte auch hero.webp ersetzen (oder die webp-Zeilen in index.html
löschen), sonst zeigen moderne Browser weiter das alte Bild.

Herkunft der jetzigen Fotos: Pexels (Pexels-Lizenz, frei nutzbar) aus der Vorlage „Glaserei“ sowie
garagentore.jpg, garagentore-2.jpg und abbruch.jpg aus dem bisherigen Entwurf. Eigene Fotos von echten
Baustellen wirken auf Kunden am stärksten; dann den Bildnachweis im Impressum anpassen.
