#!/usr/bin/env python3
"""Setzt die echte Domain überall ein (canonical, og:url, og:image, sitemap.xml, robots.txt, JSON-LD).

Aufruf:  python3 domain_setzen.py https://www.meine-domain.de
Die aktuelle Domain wird aus robots.txt gelesen (Zeile "Sitemap: …"), anfangs der Platzhalter
https://www.example-fensterbau.de. Das Skript kann beliebig oft laufen.
"""
import os, re, sys

HIER = os.path.dirname(os.path.abspath(__file__))
PLATZHALTER = "https://www.example-fensterbau.de"


def aktuelle_domain():
    try:
        t = open(os.path.join(HIER, "robots.txt"), encoding="utf-8").read()
        m = re.search(r"^Sitemap:\s*(https?://[^/\s]+)", t, re.M)
        if m:
            return m.group(1)
    except OSError:
        pass
    return PLATZHALTER


def main():
    if len(sys.argv) != 2 or not re.match(r"^https?://[a-z0-9.-]+\.[a-z]{2,}$", sys.argv[1].rstrip("/"), re.I):
        print(__doc__)
        sys.exit(1)
    neu = sys.argv[1].rstrip("/")
    alt = aktuelle_domain()
    if alt == neu:
        print("Domain ist bereits", neu)
        return
    n = 0
    for name in sorted(os.listdir(HIER)):
        if not name.endswith((".html", ".xml", ".txt")):
            continue
        p = os.path.join(HIER, name)
        t = open(p, encoding="utf-8").read()
        if alt in t:
            open(p, "w", encoding="utf-8").write(t.replace(alt, neu))
            n += 1
            print("geändert:", name)
    print(f"{alt} -> {neu} in {n} Dateien.")


if __name__ == "__main__":
    main()
