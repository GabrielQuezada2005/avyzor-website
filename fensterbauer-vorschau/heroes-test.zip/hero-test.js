(function () {
  'use strict';
  var alle = function (s, w) { return Array.prototype.slice.call((w || document).querySelectorAll(s)); };
  var tasten = alle('[data-vt]'), vars = alle('.var'), hints = alle('[data-hint]');
  var lerp = function (a, b, t) { return a + (b - a) * t; };
  function zeige(i) {
    tasten.forEach(function (t, k) { t.setAttribute('aria-pressed', k === i ? 'true' : 'false'); });
    vars.forEach(function (v) { v.hidden = v.getAttribute('data-v') !== String(i); });
    hints.forEach(function (h) { h.hidden = h.getAttribute('data-hint') !== String(i); });
    try { history.replaceState(null, '', '#v' + (i + 1)); } catch (e) {}
  }
  tasten.forEach(function (t, k) { t.addEventListener('click', function () { zeige(k); }); });
  /* 1 Vorher/Nachher */
  var vn = document.querySelector('[data-vn]');
  if (vn) {
    var r0 = vn.querySelector('[data-r="0"]');
    var setze0 = function () { vn.style.setProperty('--p', r0.value + '%'); };
    r0.addEventListener('input', setze0); setze0();
    var zieh = false;
    var pos = function (e) { var b = vn.getBoundingClientRect(); r0.value = Math.max(2, Math.min(98, ((e.clientX - b.left) / b.width) * 100)); setze0(); };
    vn.addEventListener('pointerdown', function (e) { if (e.target === r0) return; zieh = true; pos(e); });
    window.addEventListener('pointermove', function (e) { if (zieh) pos(e); });
    window.addEventListener('pointerup', function () { zieh = false; });
  }
  /* 2 Fenster auf */
  var fs = document.querySelector('[data-fs]');
  if (fs) {
    var r1 = fs.querySelector('[data-r="1"]');
    var s1 = function () { var a = (r1.value / 100) * 100; fs.style.setProperty('--a', (-a).toFixed(1) + 'deg'); fs.querySelector('.fs-r').style.setProperty('--a', (-a).toFixed(1) + 'deg'); };
    r1.addEventListener('input', s1); s1();
    window.addEventListener('scroll', function () { if (fs.offsetParent === null) return; var p = Math.min(1, window.scrollY / (window.innerHeight * 0.6)); if (window.scrollY > 4) { r1.value = Math.round(p * 100); s1(); } }, { passive: true });
  }
  /* 3 Scheibe klar */
  var bs = document.querySelector('[data-bs]');
  if (bs) {
    var r2 = bs.querySelector('[data-r="2"]'), nebel = bs.querySelector('[data-nebel]'), tx = bs.querySelector('[data-bs-text]');
    var s2 = function () { var v = r2.value / 100; nebel.style.setProperty('--n', (1 - v).toFixed(3)); tx.textContent = v < 0.15 ? 'Beschlagen' : v > 0.85 ? 'Klar' : 'Wird klar'; };
    r2.addEventListener('input', s2); s2();
  }
  /* 4 Tageslicht: 6 Uhr bis 21 Uhr */
  var tl = document.querySelector('[data-tl]');
  if (tl) {
    var r3 = tl.querySelector('[data-r="3"]'), foto = tl.querySelector('.tl-foto'), schicht = tl.querySelector('.tl-schicht'), zt = tl.querySelector('[data-tl-zeit]');
    var STUETZ = [ /* Anteil, brightness, sepia, saturate, Farbschicht */
      [0.00, 0.62, 0.30, 0.9, [150, 165, 215]],
      [0.15, 0.92, 0.35, 1.05, [255, 225, 190]],
      [0.45, 1.06, 0.00, 1.0, [255, 255, 255]],
      [0.75, 0.96, 0.35, 1.15, [255, 205, 150]],
      [0.90, 0.78, 0.55, 1.3, [255, 150, 90]],
      [1.00, 0.45, 0.30, 0.8, [90, 105, 170]] ];
    var s3 = function () {
      var t = r3.value / 100, i = 0; while (i < STUETZ.length - 2 && t > STUETZ[i + 1][0]) i++;
      var a = STUETZ[i], b = STUETZ[i + 1], u = (t - a[0]) / (b[0] - a[0]);
      foto.style.setProperty('--f', 'brightness(' + lerp(a[1], b[1], u).toFixed(3) + ') sepia(' + lerp(a[2], b[2], u).toFixed(3) + ') saturate(' + lerp(a[3], b[3], u).toFixed(3) + ')');
      schicht.style.setProperty('--c', 'rgb(' + [0, 1, 2].map(function (k) { return Math.round(lerp(a[4][k], b[4][k], u)); }).join(',') + ')');
      var min = Math.round(6 * 60 + t * 15 * 60), h = Math.floor(min / 60), m = min % 60;
      zt.textContent = (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + (m - m % 5) + ' Uhr';
    };
    r3.addEventListener('input', s3); s3();
  }
  /* 5 Karten stapeln */
  var st = document.querySelector('[data-st]');
  if (st) {
    var karten = alle('.st-karte', st), front = 2;
    var ordne = function () {
      karten.forEach(function (k, i) {
        var tiefe = (i - front + 3) % 3; /* 0 = vorn */
        k.style.setProperty('--z', 3 - tiefe); k.style.setProperty('--t', [30, 14, 3][tiefe]);
        k.style.setProperty('--s', [1, 0.93, 0.86][tiefe]); k.style.setProperty('--r', ['0deg', '-2.5deg', '2deg'][tiefe]);
      });
    };
    karten.forEach(function (k, i) {
      k.addEventListener('click', function (e) { if (i !== front) { e.preventDefault(); front = i; ordne(); } });
    });
    ordne();
  }
  var h0 = parseInt((location.hash || '').replace('#v', ''), 10);
  zeige(h0 >= 1 && h0 <= 6 ? h0 - 1 : 0);
})();
